﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckPointScript : MonoBehaviour
{
	public HahmoScript hahmo;
	[HideInInspector] public int maxHp, maxStamina, maxEnergia, ammoPistooli;
	
	// Use this for initialization
	void Start ()
	{
	}
	
	// Update is called once per frame
	void Update ()
	{
		
	}
	
	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject == hahmo.gameObject)
		{
			hahmo.checkpoint = this;
			maxHp = hahmo.maxHp;
			maxStamina = hahmo.maxStamina;
			maxEnergia = hahmo.maxEnergia;
			ammoPistooli = hahmo.ammoPistooli;
			Debug.Log("Checkpoint!");
		}
	}
}
