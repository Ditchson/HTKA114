﻿using UnityEngine;
using System.Collections;
 
[RequireComponent (typeof (CharacterController))]
public class HahmonLiike : MonoBehaviour
{
    public float nopeus = 6;
	public float hyppyKerroin = 2f;
	public Transform hahmoMalli;
    Vector3 liike;
    CharacterController controller;
	Animator anim;
	HahmoScript hahmo;
 
    // Use this for initialization
    void Awake()
	{
		Cursor.visible = false;
        controller = GetComponent<CharacterController> ();
		hahmo = GetComponent<HahmoScript>();
		anim = hahmoMalli.GetComponent<Animator>();
		AddEvent(3, 0.3f, "StartAttack", 0);
		AddEvent(3, 0.4f, "EndAttack", 0);
    }
   
    // Update is called once per frame
    void Update ()
	{
        liike = controller.velocity;
        UpdateSmoothControls();
        UpdateGravity();
		UpdateAttack();
        controller.Move (liike * Time.deltaTime);
		anim.SetInteger("hp",hahmo.hp);
    }
 
    void UpdateSmoothControls()
	{
		float ver = Input.GetAxis("Vertical");
		float hor = Input.GetAxis("Horizontal");
		
		if (Mathf.Abs(ver) + Mathf.Abs(hor) > 0) UpdateRotation(); 
		
        Vector3 input = new Vector3(hor, 0, ver);
        input = transform.TransformDirection(input);
		anim.SetFloat("vertical",Mathf.Abs(ver));
		anim.SetFloat("horizontal",hor);
		anim.SetBool("sprint", Input.GetKey(KeyCode.LeftShift));
 
        float loppuNopeus = nopeus;
        if (Input.GetKey (KeyCode.LeftShift)) loppuNopeus *= 2;
        input *= loppuNopeus;
 
        if (!controller.isGrounded)
		{
                input *= Time.deltaTime * 2;
                liike += input;
        }
		else
		{
            input.y = liike.y;
            liike = input;
        }
 
        float y = liike.y;
        liike.y = 0;
        if (liike.magnitude > loppuNopeus) liike = liike.normalized * loppuNopeus;
        liike.y = y;
 
    }
 
    void UpdateGravity()
	{
		anim.SetBool("isGrounded", controller.isGrounded);
        liike += Physics.gravity * 2 * Time.deltaTime;
        if (controller.isGrounded && Input.GetButtonDown ("Jump"))
            liike -= Physics.gravity * hyppyKerroin;
    }
	
	void UpdateAttack()
	{
		if (Input.GetMouseButtonDown(0))
		{
			UpdateRotation();
			anim.SetTrigger("attack");
		}
	}
	
	void UpdateRotation()
	{
		Quaternion rotaatio = Camera.main.transform.rotation;
		rotaatio.x = 0;
		rotaatio.z = 0;
		transform.rotation = rotaatio;
	}
	
	//Lisää animaatioon tapahtumia
	void AddEvent(int Clip, float time, string functionName, float floatParameter)
	{
		AnimationEvent animationEvent = new AnimationEvent();
		animationEvent.functionName = functionName;
		animationEvent.floatParameter = floatParameter;
		animationEvent.time = time;
		AnimationClip clip = anim.runtimeAnimatorController.animationClips[Clip];
		clip.AddEvent(animationEvent);
	}
}