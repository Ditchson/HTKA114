﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KuusiScript : MonoBehaviour {

    public Animator anim;
    public AudioClip touchSound;
    AudioSource audio;

    // Use this for initialization
    void Start () {
        anim = GetComponent<Animator>();
        audio = GetComponent<AudioSource>();
	}
	
	// Update is called once per frame
	void Update () {
	}

    private void OnTriggerEnter(Collider other)
    {
        anim.Play("On_Touch");
        audio.PlayOneShot(touchSound, 0.5f);
    }
}
