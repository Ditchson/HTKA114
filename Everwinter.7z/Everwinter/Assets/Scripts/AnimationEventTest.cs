﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationEventTest : MonoBehaviour
{
	public Transform isku;
	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		
	}
	
	public void StartAttack(int i)
    {
		isku.gameObject.SetActive(true);
    }
	
	public void EndAttack(int i)
	{
		isku.gameObject.SetActive(false);
	}
}
