﻿using UnityEngine.Audio;
using UnityEngine;

public class Askeleet : MonoBehaviour {

	public AudioSource Audio;
	CharacterController controller;

	void Awake () {

		controller = GetComponent<CharacterController>();
		Audio = GetComponent<AudioSource>();
	}
	
	void Update () {

		if (controller.isGrounded == true && controller.velocity.magnitude > 2f && Audio.isPlaying == false)
		{
			Audio.volume = Random.Range(0.6f, 1);
			Audio.pitch = Random.Range(0.7f, 1.1f);
			Audio.Play();
		}
	}


}
