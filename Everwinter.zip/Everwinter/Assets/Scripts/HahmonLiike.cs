﻿using UnityEngine;
using System.Collections;
 
[RequireComponent (typeof (CharacterController))]
public class HahmonLiike : MonoBehaviour
{
    public float nopeus = 6;
	public float vaistoNopeus = 20;
	public float hyppyKerroin = 2f;
	public Transform hahmoMalli;
	public LipasScript lipasPistooli;
	public LayerMask mihinVoiOsua;		//kaikki layerit joihin voi raycast osua
	bool onKuollut = false;
	int valittuAse = 0;
	bool onkoVaistamassa = false;
	int vaistoAika = 0;
    Vector3 liike;
    CharacterController controller;
	Animator anim;
	HahmoScript hahmo;
 
    // Use this for initialization
    void Awake()
	{
		Cursor.visible = false;
        controller = GetComponent<CharacterController> ();
		hahmo = GetComponent<HahmoScript>();
		anim = hahmoMalli.GetComponent<Animator>();
		AddEvent(3, 0.3f, "StartAttack", 0);
		AddEvent(3, 0.4f, "EndAttack", 0);
    }
   
    // Update is called once per frame
    void Update ()
	{
        liike = controller.velocity;
        if(hahmo.hp > 0 && !onkoVaistamassa)UpdateSmoothControls();
        UpdateGravity();
		if (!onKuollut) UpdateKuolema();
		if (!onKuollut) UpdateAttack();
		if (!onKuollut) UpdateVaisto();
        if (!onKuollut) controller.Move (liike * Time.deltaTime);
		anim.SetInteger("hp",hahmo.hp);
    }
 
    void UpdateSmoothControls()
	{
		float ver = Input.GetAxis("Vertical");
		float hor = Input.GetAxis("Horizontal");
		
		if (Mathf.Abs(ver) + Mathf.Abs(hor) > 0) UpdateRotation(); 
		
        Vector3 input = new Vector3(hor, 0, ver / (1 - ver + Mathf.Abs(ver)) );
        input = transform.TransformDirection(input);
		anim.SetFloat("vertical",ver);
		anim.SetFloat("horizontal",hor);
		anim.SetBool("sprint", Input.GetKey(KeyCode.LeftShift));
 
        float loppuNopeus = nopeus;
        if (Input.GetKey (KeyCode.LeftShift)) loppuNopeus *= 2;
        input *= loppuNopeus;
 
        if (!controller.isGrounded)
		{
            input *= Time.deltaTime * 2;
            liike += input;
        }
		else
		{
            input.y = liike.y;
            liike = input;
        }
 
        float y = liike.y;
        liike.y = 0;
        if (liike.magnitude > loppuNopeus) liike = liike.normalized * loppuNopeus;
        liike.y = y;
 
    }
 
    void UpdateGravity()
	{
		anim.SetBool("isGrounded", controller.isGrounded);
        liike += Physics.gravity * 2 * Time.deltaTime;
        if (controller.isGrounded && Input.GetButtonDown ("Jump") && hahmo.hp > 0)
            liike -= Physics.gravity * hyppyKerroin;
    }
	
	//Hyökkää käyttäen valittua asetta
	void UpdateAttack()
	{
		if (Input.GetKey(KeyCode.Alpha1)) valittuAse = 0;	//Keppi
		if (Input.GetKey(KeyCode.Alpha2)) valittuAse = 1;	//Normipistooli
		
		if (Input.GetMouseButtonDown(0))	//Itse hyökkäys
		{
			switch(valittuAse)
			{
				case 0:
					UpdateKeppi();
					break;
				case 1:
					UpdateAmmu();
					break;
				default:
					UpdateKeppi();
					break;
			}
		}
	}
	
	//Lyö kepillä >:(
	void UpdateKeppi()
	{
		UpdateRotation();
		anim.SetTrigger("attack");
	}
	
	//Ampuminen
	void UpdateAmmu()
	{
		UpdateRotation();
		if (hahmo.ammoPistooli <= 0) return;	//panokset loppu
		RaycastHit osuma;
		Transform cam = Camera.main.transform;
		Vector3 kohta = cam.position;
		kohta.y += 0.5f;
		
		if (Physics.Raycast(kohta, cam.forward, out osuma, Mathf.Infinity, mihinVoiOsua))
		{
			Vector3 suunta = osuma.point;
			LuotiScript ammus = lipasPistooli.AnnaAmmus();
			if (ammus)
			{
				ammus.transform.position = transform.position + Vector3.up * 1.5f;
				ammus.gameObject.SetActive(true);
				ammus.Ammu(suunta);
				hahmo.ammoPistooli--;
			}
		}
	}
	
	//Väistää
	void UpdateVaisto()
	{
		Vector3 suunta = transform.forward * Input.GetAxis("Vertical") + transform.right * Input.GetAxis("Horizontal");
		if (Input.GetKeyDown(KeyCode.LeftControl) && controller.isGrounded && vaistoAika <= 0 && hahmo.stamina >= 10)
		{
			anim.SetTrigger("vaisto");
			onkoVaistamassa = true;
			vaistoAika = 10;
			hahmo.stamina -= 10;
		}
		if (vaistoAika > 0)
		{
			vaistoAika--;
			liike = suunta * vaistoNopeus;
			return;
		}
		onkoVaistamassa = false;
	}
	
	//Päivittää hahmon rotaation
	void UpdateRotation()
	{
		Quaternion rotaatio = Camera.main.transform.rotation;
		rotaatio.x = 0;
		rotaatio.z = 0;
		transform.rotation = rotaatio;
	}
	
	void UpdateKuolema()
	{
		if (hahmo.hp <= 0)
		{
			onKuollut = true;
			anim.SetTrigger("kuole");
		}
	}
	
	//Lisää animaatioon tapahtumia
	void AddEvent(int Clip, float time, string functionName, float floatParameter)
	{
		AnimationEvent animationEvent = new AnimationEvent();
		animationEvent.functionName = functionName;
		animationEvent.floatParameter = floatParameter;
		animationEvent.time = time;
		AnimationClip clip = anim.runtimeAnimatorController.animationClips[Clip];
		clip.AddEvent(animationEvent);
	}
}