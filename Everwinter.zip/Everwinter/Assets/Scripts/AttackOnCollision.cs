﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//TODO: iskun vaikutus vihulle

public class AttackOnCollision : MonoBehaviour
{

	public int vihuLayer;
	public float vahvuus = 400f;
	public float stunnausAika;
	
	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
	}
	
	//Kun 'trigger' osuu 'collideriin'
	void OnTriggerEnter(Collider other)
	{
        if (other.gameObject.layer == vihuLayer)
		{
			VihuScript vihu = other.GetComponent<VihuScript>();
			vihu.hp--; 	//Pienentää vihun hp:ta
			vihu.stunnaus = stunnausAika;
			Rigidbody rbody = other.attachedRigidbody;
			rbody.AddForce(other.transform.forward * -vahvuus + transform.up * vahvuus, ForceMode.Impulse);
		}
    }
}
