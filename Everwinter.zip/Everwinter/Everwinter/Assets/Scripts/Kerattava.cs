﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Kerattava : MonoBehaviour {

	public Color vari;

	void Start ()
	{

	}

	void Update ()
	{
		
	}
}
