﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//TODO: tutoriaalin pohjalta tehty, muuta nimi tai luo uusi scripti

public class SampleAgentScript : MonoBehaviour
{
	public Transform kohde;
	public float huomausEtaisyys = 10f;	//kuinka läheltä vihu huomaa
	public float jahtausEtaisyys = 90f;	//kuinka kauas jahtaa, kun on huomannut
	public Vector3 aloitusPaikka;
	bool onkoHuomannut = false;
	VihuScript vihu;	//Itse tehty komponentti VihuScript, sisältää vihujen perus statistiikat
	Rigidbody rbody;
	UnityEngine.AI.NavMeshAgent agentti;	//NavMeshAgent olio, pystyy liikkumaan navmeshillä(Unityn pathfinding)
	
	
	// Use this for initialization
	void Awake()
	{
		//Alustetaan komponentit
		agentti = GetComponent<UnityEngine.AI.NavMeshAgent>();
		vihu = GetComponent<VihuScript>();
		rbody = GetComponent<Rigidbody>();
		aloitusPaikka = transform.position;
	}
	
	// Update is called once per frame
	void Update ()
	{
		float etaisyys = Vector3.Distance(transform.position, kohde.position);	//etäisyys pelaajasta
		if (etaisyys <= huomausEtaisyys) onkoHuomannut = true;	//jos pelaaja lähellä, huomaa pelaaja
		if (onkoHuomannut && etaisyys < jahtausEtaisyys)
		{
			//lähtee kulkemaan navmeshia pitkin kohti kohdetta, jos ei ole stunnattuna
			if (vihu.stunnaus <= 0) agentti.SetDestination(kohde.position);
			else
			{
				//Yrittää pysäyttää navmeshin fysiikat väliaikaisesti
				agentti.velocity = rbody.velocity;
				agentti.nextPosition = transform.position;
			}
		}
		//Jos pelaaja juoksee jahtaus etäisyyden ulkopuolelle, vihu lakkaa jahtaamasta
		if (etaisyys > jahtausEtaisyys)
		{
			onkoHuomannut = false;
			agentti.SetDestination(aloitusPaikka);
		}
	}
}
