﻿using UnityEngine;
using System.Collections;
 
[RequireComponent (typeof (CharacterController))]
public class HahmonLiike : MonoBehaviour
{
    public float nopeus = 6;
	public float hyppyKerroin = 2f;
	public Transform hahmoMalli;
    Vector3 liike;
    CharacterController controller;
	Animator anim;
 
    // Use this for initialization
    void Awake()
	{
		Cursor.visible = false;
        controller = GetComponent<CharacterController> ();
		anim = hahmoMalli.GetComponent<Animator>();
    }
   
    // Update is called once per frame
    void Update ()
	{
		Quaternion rotaatio = Camera.main.transform.rotation;
		rotaatio.x = 0;
		rotaatio.z = 0;
		transform.rotation = rotaatio;
		
        liike = controller.velocity;
        UpdateSmoothControls();
        UpdateGravity();
		UpdateAttack();
        controller.Move (liike * Time.deltaTime);
    }
 
    void UpdateSmoothControls()
	{
		float ver = Input.GetAxis("Vertical");
		float hor = Input.GetAxis("Horizontal");
        Vector3 input = new Vector3(hor, 0, ver);
        input = transform.TransformDirection(input);
		anim.SetFloat("vertical",Mathf.Abs(ver));
		anim.SetBool("sprint", Input.GetKey(KeyCode.LeftShift));
 
        float loppuNopeus = nopeus;
        if (Input.GetKey (KeyCode.LeftShift)) loppuNopeus *= 2;
        input *= loppuNopeus;
 
        if (!controller.isGrounded)
		{
                input *= Time.deltaTime * 2;
                liike += input;
        }
		else
		{
            input.y = liike.y;
            liike = input;
        }
 
        float y = liike.y;
        liike.y = 0;
        if (liike.magnitude > loppuNopeus) liike = liike.normalized * loppuNopeus;
        liike.y = y;
 
    }
 
    void UpdateGravity()
	{
		anim.SetBool("isGrounded", controller.isGrounded);
        liike += Physics.gravity * 2 * Time.deltaTime;
        if (controller.isGrounded && Input.GetButtonDown ("Jump"))
            liike -= Physics.gravity * hyppyKerroin;
    }
	
	void UpdateAttack()
	{
		if (Input.GetMouseButtonDown(0))
		{
			anim.SetTrigger("attack");
		}
	}
}