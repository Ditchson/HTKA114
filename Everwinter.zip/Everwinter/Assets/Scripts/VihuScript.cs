﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VihuScript : MonoBehaviour
{
	public int hp = 1;	//Vihun HP:t
	public float stunnaus = 0;
	
	
	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		if (stunnaus > 0) stunnaus = stunnaus - 0.01f;
		if (hp <= 0) gameObject.SetActive(false);
	}
}
