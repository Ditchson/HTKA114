﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//TODO: korvaa mappingit
//TODO: hienostuneempi hyppy ja maantunnistus


public class CharacterMovement : MonoBehaviour
{
	float loppuNopeus = 2; 
	public float hyppy = 10, vaistoNopeus = 50, juoksuNopeus = 2f, perusNopeus = 2;
	public LayerMask maaLayerit;	//Layerit jotka lasketaan maaksi(eli voi hypätä sen päältä)
	public Transform iskuOlio;
	bool onkoMaassa = true, saakoVaistaa = true;
	Rigidbody rbody;	//Hahmon rigidbody(eli perusfysiikat)
	HahmoScript hahmo;	//Hahmon statistiikat
	
	// Use this for initialization
	void Awake ()
	{
		Cursor.visible = false;
		rbody = GetComponent<Rigidbody>();		//Alustetaan rbody
		hahmo = GetComponent<HahmoScript>();	//Alustetaan hahmon scripti
	}
	
	// Update is called once per frame
	void Update ()
	{
		//Tarkistaa onko hahmon alapuolella maata
		onkoMaassa = Physics.Raycast(transform.position, -Vector3.up, 1f, maaLayerit);
		if (Input.GetKeyDown(KeyCode.Space) && onkoMaassa)
		{
			rbody.AddForce(Vector3.up*hyppy); //"Puskee" hahmon ylöspäin jos on maata alla ja on painanut välilyöntiä
		}
		
		//Säätää liikkumisnopeuden shiftin perusteella
		if (Input.GetKey(KeyCode.LeftShift)) loppuNopeus = perusNopeus + juoksuNopeus;
		else loppuNopeus = perusNopeus;
		
		//Perusliikkuminen
		float ver = Input.GetAxis("Vertical");
		float hor = Input.GetAxis("Horizontal");
		Quaternion rotation = Camera.main.transform.rotation;
		rotation.x = 0;
		rotation.z = 0;
		transform.rotation = rotation;
		
		//Laskee liikkeen
		float painoVoima = rbody.velocity.y;
		Vector3 nopeus = transform.forward * ver * loppuNopeus + transform.right * hor * loppuNopeus;
		velocity.y = painoVoima;
		if (!Input.GetKey(KeyCode.LeftControl)) rbody.velocity = nopeus;
		
		//Väistöliike
		if (Input.GetKeyDown(KeyCode.LeftControl) && saakoVaistaa)
		{
			saakoVaistaa = false;
			rbody.AddForce(transform.forward * vaistoNopeus * ver +
				transform.right * vaistoNopeus * hor, ForceMode.Impulse);
		}
		//Hyökkäys
		if (Input.GetMouseButtonDown(0))
		{
			iskuOlio.gameObject.SetActive(true);
			hahmo.energia -= 10;
		}
		else iskuOlio.gameObject.SetActive(false);
	}
}