﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class KerattavaScript : MonoBehaviour {

	// toteutetaan vähä paremmin tai jotain...
	public GameObject kerattava;

	private void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "Kerattava")
		{
			other.gameObject.SetActive(false);
			FindObjectOfType<AudioManager>().Soita("Poiminta");
		}
	}
}
