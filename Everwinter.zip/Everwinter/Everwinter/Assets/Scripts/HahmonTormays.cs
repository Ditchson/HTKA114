﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.Audio;
using UnityEngine;

public class HahmonTormays : MonoBehaviour {

	public GameObject kerattava;

	private void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "Kerattava")
		{
			Destroy (other.gameObject);
			FindObjectOfType<AudioManager>().Soita("Tormays");
		}
	}
			
}
