﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HahmoScript : MonoBehaviour
{
    public int hp = 100;
    public int maxHp = 100;
    public int energia = 100;
    public int maxEnergia = 100;
	public float regNopeus = 0.5f;	//Energian palautumisnopeus
    public Slider EnkkaPalkki;
	float energiaReg = 0;

    // Use this for initialization
    void Start()
    {

    }

    public void laskeEnkka(int damage)
    {
        hp = hp - damage;
        EnkkaPalkki.value = hp--;
    }


    // Update is called once per frame
    void Update()
    {
		if (Time.time > energiaReg)
		{
			energiaReg = Time.time + regNopeus;
			if (energia < maxEnergia) energia++;
		}
    }
}
