﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HahmoScript : MonoBehaviour
{
    public int hp = 100;
    public int maxHp = 100;
	public int stamina = 100;
	public int maxStamina = 100;
    public int energia = 100;
    public int maxEnergia = 100;
	public float regNopeus = 0.5f;	//Staminan palautumisnopeus
    public Slider enkkaPalkki;
    public Slider staminaPalkki;
    public Text pistooliUI;
	float staminaReg = 0;
	public int ammoPistooli = 0;

    // Use this for initialization
    void Start()
    {
        pistooliUI.text = ammoPistooli+"";
    }

    public void laskeEnkka(int damage)
    {
        hp = hp - damage;
        enkkaPalkki.value = hp;
    }

    public void laskePistooli(int vahennys)
    {
        ammoPistooli = ammoPistooli - vahennys;
        pistooliUI.text = ammoPistooli+"";
    }


    // Update is called once per frame
    void Update()
    {
		if (Time.time > staminaReg)
		{
			staminaReg = Time.time + regNopeus;
			if (stamina < maxEnergia) stamina++;
		}
        staminaPalkki.value = stamina;
    }
}
