﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//TODO: iskun vaikutus vihulle

public class AttackOnCollision : MonoBehaviour
{

	public int vihuLayer;
	public int pelaajaLayer;
	public float vahvuus = 400f;
	public float stunnausAika;
	public int dmg = 1;
	
	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
	}
	
	//Kun 'trigger' osuu 'collideriin'
	void OnTriggerEnter(Collider other)
	{
        if (other.gameObject.layer == vihuLayer)
		{
			VihuScript vihu = other.GetComponent<VihuScript>();
			vihu.hp -= dmg; 	//Pienentää vihun hp:ta
			vihu.stunnaus += stunnausAika;
			Rigidbody rbody = other.attachedRigidbody;
			rbody.AddForce(other.transform.forward * -vahvuus + transform.up * vahvuus, ForceMode.Impulse);
		}
		if (other.gameObject.layer == pelaajaLayer)
		{
			HahmoScript hahmo = other.GetComponent<HahmoScript>();
			hahmo.hp -= dmg; 	//Pienentää vihun hp:ta
			Animator anim = other.GetComponentInChildren<Animator>();
			anim.SetTrigger("vahinko");
		}
    }
}
