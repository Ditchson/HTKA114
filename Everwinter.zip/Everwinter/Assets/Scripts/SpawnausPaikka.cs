﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnausPaikka : MonoBehaviour
{
	public Transform kohde;				//Pelaaja
	public float huomausEtaisyys = 10f;	//kuinka läheltä vihut huomaa
	public float jahtausEtaisyys = 90f;	//kuinka kauas vihut jahtaa, kun on huomannut
	public bool onHuomannut = false;
	public float reaktioAika = 10f;
	[HideInInspector] public float etaisyys;
	
	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		etaisyys = Vector3.Distance(transform.position, kohde.position);
		if (etaisyys <= huomausEtaisyys)
		{
			if (reaktioAika > 0) reaktioAika -= 0.1f;
			if (reaktioAika <= 0) onHuomannut = true;
		}
		if (etaisyys >= jahtausEtaisyys)
		{
			reaktioAika = 5f;
			onHuomannut = false;
		}
	}
}
